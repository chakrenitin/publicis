Problem Statement : 
Develop a service to find the historical Bitcoin price with the highest and lowest  price markers for a user provided Start date, End date and Output Currency.


Swagger Home URL : http://localhost:8080/swagger-ui/index.html

