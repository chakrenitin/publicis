package com.publicis.demo.dto;

public interface ApiResponse {

}
